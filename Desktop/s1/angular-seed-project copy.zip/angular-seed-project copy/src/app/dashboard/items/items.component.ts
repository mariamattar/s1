import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-items',
  template: ``
})
export class ItemsComponent {}
